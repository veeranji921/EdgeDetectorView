package com.example.edgeviewer

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.TextureView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {

    private lateinit var textureView: TextureView
    private lateinit var glSurfaceView: GLSurfaceView
    private lateinit var renderer: OpenGLRenderer

    companion object {
        init {
            System.loadLibrary("native-lib")
        }
    }

    external fun processFrame(input: ByteArray, width: Int, height: Int): ByteArray

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textureView = findViewById(R.id.camera_view)
        glSurfaceView = findViewById(R.id.gl_view)

        renderer = OpenGLRenderer(this)
        glSurfaceView.setEGLContextClientVersion(2)
        glSurfaceView.setRenderer(renderer)

        CameraHelper(this, textureView) { frame, w, h ->
            val processed = processFrame(frame, w, h)
            renderer.updateFrame(processed, w, h)
        }
    }
}
