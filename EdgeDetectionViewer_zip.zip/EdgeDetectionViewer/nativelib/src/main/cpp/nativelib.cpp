#include <jni.h>
#include <opencv2/opencv.hpp>
#include "edge_processor.cpp"

using namespace cv;

extern "C" JNIEXPORT jbyteArray  extern "C" JNICALL
Java_com_example_edgeviewer_MainActivity_processFrame(
        JNIEnv *env, jobject, jbyteArray input, jint width, jint height) {

    jbyte *inputBytes = env->GetByteArrayElements(input, NULL);
    Mat yuv(height + height / 2, width, CV_8UC1, inputBytes);
    Mat bgr;
    cvtColor(yuv, bgr, COLOR_YUV2BGR_NV21);

    Mat edges = processEdges(bgr);

    std::vector<uchar> buf;
    imencode(".jpg", edges, buf);

    jbyteArray output = env->NewByteArray(buf.size());
    env->SetByteArrayRegion(output, 0, buf.size(), reinterpret_cast<jbyte*>(buf.data()));
    env->ReleaseByteArrayElements(input, inputBytes, JNI_ABORT);
    return output;
}
