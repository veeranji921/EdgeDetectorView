#include <opencv2/opencv.hpp>
using namespace cv;

Mat processEdges(Mat &frame) {
    Mat gray, edges;
    cvtColor(frame, gray, COLOR_BGR2GRAY);
    Canny(gray, edges, 80, 150);
    return edges;
}
